package com.example.adaptadoresandresgomez.detalle;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.adaptadoresandresgomez.R;
import com.squareup.picasso.Picasso;

public class DetalleUsuarioActivity extends AppCompatActivity {
    ImageView imgUsuario;
    TextView txtNombre, txtCategoria;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detalle_usuario);

        imgUsuario = findViewById(R.id.imgUsuarioDetalle);
        txtNombre = findViewById(R.id.txtNombreDetalle);
        txtCategoria = findViewById(R.id.txtCategoriaDetalle);

        // Obtener los datos pasados desde MainActivity
        String nombre = getIntent().getStringExtra("nombre");
        String categoria = getIntent().getStringExtra("categoria");
        String imagenUrl = getIntent().getStringExtra("imagen");

        // Mostrar los datos en la nueva pantalla
        txtNombre.setText(nombre);
        txtCategoria.setText(categoria);
        Picasso.get().load(imagenUrl).into(imgUsuario);
    }
}
