package com.example.adaptadoresandresgomez;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.adaptadoresandresgomez.adaptadores.UsuarioAdaptador;
import com.example.adaptadoresandresgomez.clases.Usuarios;
import com.example.adaptadoresandresgomez.detalle.DetalleUsuarioActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements UsuarioAdaptador.OnItemClickListener {
    RecyclerView rcv_usuarios;
    List<Usuarios> lista = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        rcv_usuarios = findViewById(R.id.rcv_usuarios);

        // Añadir usuarios a la lista
        lista.add(new Usuarios("https://randomuser.me/api/portraits/men/1.jpg", "John Doe", "rock"));
        lista.add(new Usuarios("https://randomuser.me/api/portraits/women/2.jpg", "Jane Smith", "pop"));
        lista.add(new Usuarios("https://randomuser.me/api/portraits/men/3.jpg", "Michael Johnson", "jazz"));
        lista.add(new Usuarios("https://randomuser.me/api/portraits/women/4.jpg", "Emily Davis", "blues"));
        lista.add(new Usuarios("https://randomuser.me/api/portraits/men/5.jpg", "David Brown", "hip-hop"));
        lista.add(new Usuarios("https://randomuser.me/api/portraits/women/6.jpg", "Sophia Wilson", "classical"));
        lista.add(new Usuarios("https://randomuser.me/api/portraits/men/7.jpg", "James Taylor", "reggae"));
        lista.add(new Usuarios("https://randomuser.me/api/portraits/women/8.jpg", "Olivia Thomas", "electronic"));
        lista.add(new Usuarios("https://randomuser.me/api/portraits/men/9.jpg", "Robert Lee", "metal"));
        lista.add(new Usuarios("https://randomuser.me/api/portraits/women/10.jpg", "Isabella Martin", "folk"));
        lista.add(new Usuarios("https://randomuser.me/api/portraits/men/11.jpg", "William Garcia", "country"));

        rcv_usuarios.setLayoutManager(new LinearLayoutManager(this));
        rcv_usuarios.setAdapter(new UsuarioAdaptador(lista, this));
    }

    @Override
    public void onItemClick(Usuarios usuario) {
        Intent intent = new Intent(MainActivity.this, DetalleUsuarioActivity.class);
        intent.putExtra("nombre", usuario.getNombre());
        intent.putExtra("categoria", usuario.getCategoria());
        intent.putExtra("imagen", usuario.getImagen());
        startActivity(intent);
    }
}
