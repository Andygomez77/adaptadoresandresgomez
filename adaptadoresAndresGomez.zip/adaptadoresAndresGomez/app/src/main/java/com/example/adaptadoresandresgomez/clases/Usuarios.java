package com.example.adaptadoresandresgomez.clases;

public class Usuarios
{
    private  String imagen;
    private  String nombre;
    private  String categoria;

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public Usuarios(String imagen, String nombre, String categoria) {
        this.imagen = imagen;
        this.nombre = nombre;
        this.categoria = categoria;
    }
}
